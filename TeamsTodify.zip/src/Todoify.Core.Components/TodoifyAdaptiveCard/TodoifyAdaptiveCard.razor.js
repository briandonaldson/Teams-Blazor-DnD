﻿export function renderCard(id, cardString)
{    
    var card = JSON.parse(cardString);

    var item = document.getElementById(id);
    
    var adaptiveCard = new AdaptiveCards.AdaptiveCard();
    
    adaptiveCard.hostConfig = new AdaptiveCards.HostConfig({
        fontFamily: "Segoe UI, Helvetica Neue, sans-serif"
    });
           
    adaptiveCard.onExecuteAction = function (action) { alert("Ow!"); }
    
    adaptiveCard.parse(card);
    
    var renderedCard = adaptiveCard.render();
        
    item.appendChild(renderedCard);
}