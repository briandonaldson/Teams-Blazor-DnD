﻿export function preventDefaultOnTouchStart() {
    console.log('preventDefaultOnTouchStart start');
    document.addEventListener('touchstart', function (e) { e.preventDefault(); }, false);
    console.log('preventDefaultOnTouchStart complete');
}