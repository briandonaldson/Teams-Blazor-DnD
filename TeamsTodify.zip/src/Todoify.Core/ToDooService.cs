﻿using MongoDB.Driver;

namespace Todoify.Core
{
    public class ToDooService
    {
        private readonly IMongoDatabase _db;
        private readonly IMongoCollection<ToDoo> _todoos;
        private readonly MongoClient _client;
        public ToDooService()
        {
            _client = new MongoClient("mongodb://localhost:27017");
            _db = _client.GetDatabase(nameof(ToDoo));

            _todoos = _db.GetCollection<ToDoo>(nameof(ToDoo));
        }

        public async Task<List<ToDoo>> GetToDoosAsync()
        {
            var results = new List<ToDoo>();
            
            using (var cursor = await _todoos.FindAsync(x => true))
            {
                while (await cursor.MoveNextAsync())
                {
                    var batch = cursor.Current;
                    foreach (var document in batch)
                    {
                        results.Add(document);
                    }
                }
            }

            return results;
        }

        public Task Insert(ToDoo todoo)
        {
            _todoos.InsertOne(todoo);

            return Task.CompletedTask;
        }

        public Task Update(ToDoo toDoo)
        {
            _todoos.ReplaceOne(x => x.Id == toDoo.Id, toDoo);

            return Task.CompletedTask;
        }
    }
}