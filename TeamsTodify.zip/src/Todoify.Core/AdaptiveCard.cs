﻿namespace Todoify.Core
{
    public class AdaptiveCard
    {
        public string type { get; set; }
        public string version { get; set; }
        public AdaptiveCardBody[] body { get; set; }
        public AdaptiveCardAction[] actions { get; set; }
    }

    public class AdaptiveCardBody
    {
        public string type { get; set; }
        public string url { get; set; }
        public string text { get; set; }
    }

    public class AdaptiveCardAction
    {
        public string type { get; set; }
        public string title { get; set; }
        public string url { get; set; }
    }
}
