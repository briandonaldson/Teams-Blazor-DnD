﻿
namespace Todoify.Core
{
    public enum ToDooStatus
    {
        InComplete,
        Completed
    }
}
