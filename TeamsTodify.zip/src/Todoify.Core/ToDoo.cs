﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.IdGenerators;

namespace Todoify.Core
{
    public class ToDoo
    {
        [BsonId(IdGenerator = typeof(CombGuidGenerator))]
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public ToDooStatus Status { get; set; }
    }
}
