# Todoify

A todoo app ;)

Requires a running default mongodb, VS Teams Toolkit.

## Test it out

Run ```ngrok http https://localhost:44302```

Replace /.fx/configs/config.local.json values of ngrok.io with latest base url.
Replace manifest.xml values the same way.

### Teams

R-click TeamsTodoify project > Teams Toolkit > Prepare App Dependencies and then run Zip appPackage for local. Upload custom app in teams by selecting the app package.

The app should be available on desktop, web, and mobile.

### Outlook

Click on the addins button in the ribbon bar > click my addins > click add a custom addin. Select the manifest.xml.

The app will be available by clicking the Show ToDoos button in the ribbon bar.


### fin

Run TeamsTodoify F5 in VS and open an app.